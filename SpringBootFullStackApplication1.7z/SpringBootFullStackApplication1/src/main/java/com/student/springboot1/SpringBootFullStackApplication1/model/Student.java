package com.student.springboot1.SpringBootFullStackApplication1.model;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



import org.springframework.stereotype.Component;
//import org.hibernate.annotations.DynamicInsert;
import org.hibernate.*;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;



//spring data jpa jars
@Component



@Entity
@Table(name = "students")

@DynamicInsert
@DynamicUpdate


public class Student {

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private int id;
private String name;
private int age;
private String course;



public Student() {
}



public int getId() {
return id;
}



public void setId(int id) {
this.id = id;
}



public String getName() {
return name;
}



public void setName(String name) {
this.name = name;
}



public int getAge(int age) {
return age;
}



public void setAge(int age) {
this.age = age;
}

public String getCourse() {
return course;
}



public void setCourse(String course) {
this.course = course;
}





@Override
public String toString() {
return "Employee [Id=" + id + ", Name=" + name + ", Age=" + age + ", Course=" + course + "]";
}





}
