package com.student.springboot1.SpringBootFullStackApplication1.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import com.student.springboot1.SpringBootFullStackApplication1.model.Student;
@Repository
public interface StudentRepository extends JpaRepository<Student, Integer> {

}
