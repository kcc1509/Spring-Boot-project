package com.student.springboot1.SpringBootFullStackApplication1.controller;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;


import com.student.springboot1.SpringBootFullStackApplication1.model.Student;
import com.student.springboot1.SpringBootFullStackApplication1.service.MyService;
@RestController
@CrossOrigin(origins = "http://localhost:4200",allowedHeaders = {"GET","POST","PUT","DELETE"})
@RequestMapping("/api/v1")

public class StudentController {
	@Autowired
	MyService service;

	@Bean
	public WebMvcConfigurer corsConfigurer() {
	return new WebMvcConfigurerAdapter() {
	@Override
	public void addCorsMappings(CorsRegistry registry) {
	registry.addMapping("/**").allowedOrigins("*");
	}
	};
	}

	// localhost:8080/employee/all

	@RequestMapping(value = "/students/all", method = RequestMethod.GET)
	public List<Student> getStudents() {
	System.out.println(this.getClass().getSimpleName() + " getStudents() method invoked");



	return service.getStudents();
	}



	// localhost:8080/projectname/student/1234 ==> 1234 @PathVariable id
	@RequestMapping(value = "/students/{id}", method = RequestMethod.GET)
	public Student getStudentById(@PathVariable int id) throws Exception {
	System.out.println(this.getClass().getSimpleName() + " getStudentById() method invoked");
	Optional<Student> stud = service.getStudentById(id);



	if (!stud.isPresent())
	throw new Exception("could not find Student with id " + id);



	return stud.get();
	}



	@RequestMapping(value = "/students/add", method = RequestMethod.POST)
	public Student createStudent(@RequestBody Student stud) {
	System.out.println(this.getClass().getSimpleName() + " createStudent method invoked");
	return service.addNewStudent(stud);
	}



	@RequestMapping(value = "/students/update/{id}", method = RequestMethod.PUT)
	public Student updateStudent(@PathVariable int id, @RequestBody Student stud1) throws Exception {
	System.out.println(this.getClass().getSimpleName() + " createStudent method invoked");



	Optional<Student> stud = service.getStudentById(id);

	if (!stud.isPresent())
	throw new Exception("could not find Employee with id " + id);



	if (stud1.getName() == null || stud1.getName().isEmpty())
	stud1.setName(stud.get().getName());
	if (stud1.getAge(id)==0)
	stud1.setAge(stud.get().getAge(id));
	if (stud1.getCourse() == null || stud1.getCourse().isEmpty())
	stud1.setCourse(stud.get().getCourse());
	

	



	// for where clause
	stud1.setId(id);



	return service.updateStudent(stud1);



	}



	@RequestMapping(value = "/students/delete/{id}", method = RequestMethod.DELETE)
	public void deleteStudentById(@PathVariable int id) throws Exception {
	System.out.println(this.getClass().getSimpleName() + " deleteStudentById() method invoked");
	Optional<Student> stud = service.getStudentById(id);



	if (!stud.isPresent())
	throw new Exception("could not find Employee with id " + id);



	service.deleteStudentById(id);
	}



	@RequestMapping(value = "/students/deleteall", method = RequestMethod.DELETE)
	public void deleteAll() {
	System.out.println(this.getClass().getSimpleName() + " deleteAll() method invoked");



	service.deleteAllStudents();
	}



}
