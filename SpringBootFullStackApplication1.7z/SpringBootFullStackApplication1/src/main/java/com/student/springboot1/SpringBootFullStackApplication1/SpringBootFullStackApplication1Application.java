package com.student.springboot1.SpringBootFullStackApplication1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootFullStackApplication1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootFullStackApplication1Application.class, args);
	}

}
