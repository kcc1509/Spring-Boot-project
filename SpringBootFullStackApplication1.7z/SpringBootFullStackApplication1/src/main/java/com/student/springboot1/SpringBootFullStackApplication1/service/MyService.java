package com.student.springboot1.SpringBootFullStackApplication1.service;

import java.util.List;
import java.util.Optional;



import com.student.springboot1.SpringBootFullStackApplication1.model.Student;

public interface MyService {
	public List<Student> getStudents();
	public Optional<Student> getStudentById(int id);
	public Student addNewStudent(Student stud);
	public Student updateStudent(Student stud);
	public void deleteStudentById(int id);
	public void deleteAllStudents();
	

}
