package com.student.springboot1.SpringBootFullStackApplication1.service;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.student.springboot1.SpringBootFullStackApplication1.model.Student;
import com.student.springboot1.SpringBootFullStackApplication1.repository.StudentRepository;

@Service
public class MyServiceImpl implements MyService {
	@Autowired
	StudentRepository dao;



	@Override
	public List<Student> getStudents() {
	// TODO Auto-generated method stub
	return dao.findAll(); // select all
	}



	@Override
	public Optional<Student> getStudentById(int id) {
	// TODO Auto-generated method stub
	return dao.findById(id); // select one record based on id
	}



	@Override
	public Student addNewStudent(Student stud) {
	// TODO Auto-generated method stub
	return dao.save(stud);
	}



	@Override
	public Student updateStudent(Student stud) {
	// TODO Auto-generated method stub
	return dao.save(stud);
	}



	@Override
	public void deleteStudentById(int id) {
	// TODO Auto-generated method stub
	dao.deleteById(id);
	}



	@Override
	public void deleteAllStudents() {
	dao.deleteAll();



	}



}
