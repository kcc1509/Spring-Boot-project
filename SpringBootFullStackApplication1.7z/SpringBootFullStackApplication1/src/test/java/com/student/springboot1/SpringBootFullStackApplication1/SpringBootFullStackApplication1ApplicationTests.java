package com.student.springboot1.SpringBootFullStackApplication1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootFullStackApplication1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
